import React from 'react'

const FailedActivity = ({mssg}) => {
 

	return (

		<div className='flex items-center mt-[150px] text-[30px] flex-col'>

			<h2>{mssg}</h2>

		</div>

	);


}

export default FailedActivity