# READ THIS FILE AND STEPS CAREFULLY

# ADMIN EMAIL AND PASSWORD

	email: admin@gmail.com
	password: admin123

# AFTER EXTRACTING PROJECT

	STEP 1 - Go inside USER folder, type "cmd" in the top folder url bar.
	STEP 2 - Now, in the Command Prompt, type "code ." to open your project in VS Code.
	STEP 3 - Now, Goto Terminal, Type "npm install" and wait till the installation over.

# TO RUN THE PROJECT

	STEP 1 - GOTO Terminal type "npm start" it will automatically run your project.

# WHEN YOU ADD PROPER DATA

	STEP 1 - Goto .env file in USER project folder and Remove the # from [17-22 & 25] and remove the lines from [5-15].
	STEP 2 - Goto .env file in ADMIN project folder and Remove the # from [10-15] and remove the lines from [1-8].
	
	# Before review Data :
		Add totally 3 Accounts [One gmail, 2 Email]
		Minimum 9 Posts try to add.
		Make sure, you follow all among these three accounts & like among these 9 posts.

	# In Review :
		Add 2 Accounts [One Gmail, One Email]
		Add one post and show.
		Show all the feature one by one.

# OPENING AND RUNNING ADMIN PROJECT
	
	STEP 1 - Go inside ADMIN folder, type "cmd" in the top folder url bar.
	STEP 2 - Now, in the Command Prompt, type "code ." to open your project in VS Code.
	STEP 3 - Now, Goto Terminal, Type "npm install" and wait till the installation over.
	STEP 4 - GOTO Terminal type "npm start" it will automatically run your project.

# FOR CLOSING THE RUNNING PROJECT

	Delete the Terminal or Click CTRL + C in the terminal and Type "y" to exit.


