import React from 'react'
import SideNav from '../components/SideNav';
import NavBar from '../components/NavBar';
import { Box, Stack } from '@mui/material';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import '../styles/admin-home.css'
import PeopleIcon from '@mui/icons-material/People';
import CurrencyRupeeIcon from '@mui/icons-material/CurrencyRupee';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import useGetData from '../custom-hooks/useGetData'
import ColorLensRoundedIcon from '@mui/icons-material/ColorLensRounded';
import LoadingPage from './LoadingPage';

const Dashboard = () => {

	const { data: products, loading } = useGetData('pins')
	const { data: users } = useGetData('users')

	return (

		<>

			{
				loading ? <LoadingPage /> :

				<div className='bgcolor'>
					<NavBar />
					<Box height={70} />
					<Box sx={{ display: 'flex' }}>
						<SideNav />

						<Box component="main" sx={{ flexGrow: 1, p: 3 }}>

							<Grid container spacing={2}>

								<Grid item xs={6}>

									<Stack spacing={2} direction={'row'}>

										<Card sx={{ minWidth: 49 + "%", height: 150 }} className='g'>
											<div className="iconstyle">
												<CurrencyRupeeIcon />
											</div>
											<CardContent>
												<Typography className='text-white' gutterBottom variant="h5" component="div">
													₹ 5000.00
												</Typography>
												<Typography gutterBottom variant="h5" component="div" sx={{ color: '#ccd1d1' }}>
													Total Sales
												</Typography>
											</CardContent>

										</Card>

										<Card sx={{ minWidth: 49 + "%", height: 150 }} className='g'>
											<div className="iconstyle">
												<ShoppingCartIcon />
											</div>
											<CardContent>
												<Typography className='text-white' gutterBottom variant="h5" component="div">
													40
												</Typography>
												<Typography gutterBottom variant="h5" component="div" sx={{ color: '#ccd1d1' }}>
													Total Buys
												</Typography>
											</CardContent>

										</Card>

									</Stack>

								</Grid>

								<Grid item xs={6}>

									<Stack spacing={2} direction={'row'}>

										<Card sx={{ minWidth: 49 + "%", height: 150 }} className='g'>
											<div className="iconstyle">
												<ColorLensRoundedIcon />
											</div>
											<CardContent>
												<Typography gutterBottom variant="h5" component="div" sx={{ color: '#ccd1d1' }}>
													Total Posts
												</Typography>
												<Typography className='text-white' gutterBottom variant="h5" component="div">
													{products.length}
												</Typography>
											</CardContent>

										</Card>

										<Card sx={{ minWidth: 49 + "%", height: 150 }} className='g'>
											<div className="iconstyle">
												<PeopleIcon />
											</div>
											<CardContent>
												<Typography gutterBottom variant="h5" component="div" sx={{ color: '#ccd1d1' }}>
													Total Users
												</Typography>
												<Typography className='text-white' gutterBottom variant="h5" component="div">
													{users.length}
												</Typography>
											</CardContent>

										</Card>

									</Stack>

								</Grid>

							</Grid>


						</Box>
					</Box>

				</div>
				
			}

		</>

	);

}

export default Dashboard