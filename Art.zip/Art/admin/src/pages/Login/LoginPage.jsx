import React, { useState } from 'react'
import './script.js'
import { useNavigate } from 'react-router-dom'
import './login-page.css'
import { auth } from '../../Shared/firebase.js'
import Swal from 'sweetalert2';

// Firebase Imports
import { signInWithEmailAndPassword } from "firebase/auth";
import { GoogleSvg } from '../../custom-hooks/useImage.js'
import LoadingPage from '../LoadingPage.jsx'

const LoginPage = () => {

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [loading, setLoading] = useState(false)
    const navigate = useNavigate()

    const signIN = async (e) => {
        e.preventDefault()
        setLoading(true)

        try {

            const userCredential = await signInWithEmailAndPassword(
                auth,
                email,
                password
            )

            const user = userCredential.user

            console.log(user)
            setLoading(false)
            Swal.fire("Welcome Back Admin", 'Logged In Successfully', 'success');
            navigate('/admin/home')

        } catch (error) {
            setLoading(false)
            Swal.fire('Try again later', `${error.message}`, 'error')
        }
    }

    return (

        <section class="containers forms">

            {
                loading ? <LoadingPage /> :

                    <div class="form login">
                        <div class="form-content">
                            <header className='head'>Admin Login</header>
                            <form onSubmit={signIN}>
                                <div class="field input-field">
                                    <input type="email" placeholder="Email" class="input" value={email} onChange={e => setEmail(e.target.value)} />
                                </div>
                                <div class="field input-field">
                                    <input type="password" placeholder="Password" class="password" value={password} onChange={e => setPassword(e.target.value)} />
                                    <i class='bx bx-hide eye-icon'></i>
                                </div>

                                <div class="field button-field">
                                    <button>Login</button>
                                </div>
                            </form>
                        </div>
                        <div class="line"></div>
                        <div class="media-options">
                            <a href="/" class="field google">
                                <img src={GoogleSvg} alt="" class="google-img" />
                                <span>Login with Google</span>
                            </a>
                        </div>
                    </div>
            }

        </section>

    );

}

export default LoginPage