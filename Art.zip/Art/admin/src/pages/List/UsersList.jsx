import React, { useState, useEffect } from 'react'
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import { Typography } from '@mui/material';
import { db } from '../../Shared/firebase';
import Box from '@mui/material/Box'
import Divider from '@mui/material/Divider'
import '../../styles/admin-home.css'
import { getDocs, collection } from 'firebase/firestore';

export default function StickyHeadTable() {

	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(5);
	const [rows, setRows] = useState([]);

	const empCollectionRef = collection(db, 'users');

	useEffect(() => {
		getUsers();
	});

	const getUsers = async () => {
		const data = await getDocs(empCollectionRef);
		setRows(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
	};

	const handleChangePage = (event, newPage) => {
		setPage(newPage);
	};

	const handleChangeRowsPerPage = (event) => {
		setRowsPerPage(+event.target.value);
		setPage(0);
	};

	return (
		<Paper sx={{ width: '100%', overflow: 'hidden', padding: '0px 20px' }}>

			<Typography gutterBottom variant='h5' component='div' sx={{ padding: '20px' }}>
				All Users List
			</Typography>

			<Divider />

			<Box height={10} />

			<Box height={10} />

			<TableContainer sx={{ maxHeight: 440 }}>

				<Table stickyHeader aria-label="sticky table">

					<TableHead>
						<TableRow>

							<TableCell align='left' style={{ minWidth: '100px' }}>
								<h5>User Image</h5>
							</TableCell>
							
							<TableCell align='left' style={{ minWidth: '100px' }}>
								<h5>Username</h5>
							</TableCell>

							<TableCell align='left' style={{ minWidth: '100px' }}>
								<h5>Email</h5>
							</TableCell>

						</TableRow>
					</TableHead>

					<TableBody>
						{rows
							.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
							.map((row) => {
								return (
									<TableRow hover role="checkbox" tabIndex={-1}>

										<TableCell key={row.id} align='left'>
											<img className='p-img' src={row.photoURL} alt="" />
										</TableCell>

										<TableCell key={row.id} align='left'>
											<h6>{row.name}</h6>
										</TableCell>

										<TableCell key={row.id} align='left'>
											<h6>{row.email}</h6>
										</TableCell>

									</TableRow>
								);
							})}
					</TableBody>
				</Table>

			</TableContainer>

			<TablePagination
				rowsPerPageOptions={[10, 25, 100]}
				component="div"
				count={rows.length}
				rowsPerPage={rowsPerPage}
				page={page}
				onPageChange={handleChangePage}
				onRowsPerPageChange={handleChangeRowsPerPage}
			/>
		</Paper>
	);
}