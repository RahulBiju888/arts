import React from 'react'
import SideNav from '../components/SideNav';
import { Box } from '@mui/material';
import NavBar from '../components/NavBar';
import TabsList from '../components/Settings/TabsList';

const Settings = () => {
  
	return (

		<>

			<div className="bgcolor">
				<NavBar />
				<Box height={70} />
				<Box sx={{ display: 'flex' }}>
					<SideNav />

					<Box component="main" sx={{ flexGrow: 1, p: 3 }}>
					
						<TabsList />
						
					</Box>
				</Box>

			</div>

		</>

	);

}

export default Settings