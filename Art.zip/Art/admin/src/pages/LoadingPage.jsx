import React from 'react'

const LoadingPage = () => {

	return (

		<center>
			<h2 className='mx-auto p-6'>Loading...</h2>
		</center>

	)
}

export default LoadingPage