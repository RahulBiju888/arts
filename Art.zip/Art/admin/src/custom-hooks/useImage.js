import GoogleSvg from '../assets/icons/google.svg'


export {
	GoogleSvg,
}