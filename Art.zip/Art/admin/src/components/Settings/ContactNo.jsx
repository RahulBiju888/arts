import React, { useEffect, useState } from 'react'
import { Col, Container, Row, Form, FormGroup } from 'reactstrap';
import useGetData from '../../custom-hooks/useGetData';
import { addDoc, collection, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../Shared/firebase';
import Swal from 'sweetalert2';

const ContactNo = () => {

	const docRef = collection(db, 'settings')

	const [phone, setPhone] = useState('')

	const addPhone = (e) => {

		e.preventDefault()

		try {
			
			addDoc(docRef, {
				contactNo: phone
			})
			Swal.fire("Success", 'Contact added Successfully', 'success');

		} catch (error) {
			Swal.fire('Try again later', `${error.message}` , 'error')
		}
	}

  return (
	
	<section className='mt-0 pt-4'>
		<Container className='border border-danger p-3'>
			
			<Row>

				<h5 className='mb-2 text-dark'>Contact Phone Number</h5>
				
				<Col lg='12'>

					<Form>
			
						<div className='d-flex align-items-center justify-content-between gap-5'>
							<FormGroup className='form__group w-50'>

								<input 
									type="number"
									placeholder='Contact Number'
									onChange={e => setPhone(e.target.value)}
									value={phone}
								/>

							</FormGroup>

							<button className="buy__btn mt-0" type='submit'>Save</button>
						</div>


					</Form>
					
				</Col>
				
			
			
			</Row>

		</Container>
	</section>

  )
}

export default ContactNo