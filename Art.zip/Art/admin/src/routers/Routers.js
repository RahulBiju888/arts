import { Routes, Route, Navigate } from 'react-router-dom';

// Admin Website Imports
import LoginPage from '../pages/Login/LoginPage';
import AdminProtected from './AdminProtected';
import Dashboard from '../pages/Dashboard';
import Settings from '../pages/Settings';
import Products from '../pages/Products';
import AllUsers from '../pages/Users';

const Routers = () => {

	return (
		<Routes>

			{/* Admin Routes */}

			<Route path='/' element={<Navigate to='admin' />} />
			<Route path='/admin' element={<LoginPage />} />
			<Route path='/admin' element={<AdminProtected />}>
				<Route path='/admin/home' element={<Dashboard />} />
				<Route path='/admin/settings' element={<Settings />} />
				<Route path='/admin/pins' element={<Products />} />
				<Route path='/admin/all-users' element={<AllUsers />} />
			</Route>

		</Routes>
	);
};

export default Routers;