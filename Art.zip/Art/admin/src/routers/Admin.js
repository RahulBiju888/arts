import React from 'react'
import useAuth from '../custom-hooks/useAuth'
import { Navigate } from 'react-router-dom'

const Admin = () => {
  
	const {currentUser} = useAuth()

	return currentUser ? <Navigate to={'/admin/dashboard'} /> : <Navigate to={'/admin'} />
}

export default Admin